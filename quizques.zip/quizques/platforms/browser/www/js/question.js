var questions =[
{
	"question":" The first mechanical computer designed by charles Babbage was called ?",
	"option1": "Asuaus",
	"option2": "ABACUS",
	"option3": "ABACUS",
	"option3": "ABACUS",
	"answer": "2"
},{
	"question":" The first mechanical computer designed by charles Babbage was called ?",
	"option1": "ABACUS",
	"option2": "ABACUS",
	"option3": "ABACUS",
	"option3": "ABACUS",
	"answer": "3"
	},
	{
	"question":" The first mechanical computer designed by charles Babbage was called ?",
	"option1": "ABACUS",
	"option2": "ABACUS",
	"option3": "ABACUS",
	"option3": "ABACUS",
	"answer": "3"
	};

	]